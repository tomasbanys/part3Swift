import UIKit

class primeNumbers{
    func printNumbers(from n: Int, upto m: Int){
        var countOfPrimeNumbers = 0
        for number in n...m {
            var count = 0
            for num in n..<number {
                if number % num == 0 {
                    count += 1
                 }
            }
            if count <= 2 {
                if(number > 1){
                    countOfPrimeNumbers += 1
                }
            }
        }
        print(countOfPrimeNumbers)
    }
}

let numbersRange = primeNumbers()

numbersRange.printNumbers(from: 1, upto: 10)
